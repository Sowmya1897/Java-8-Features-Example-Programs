package com.methodreference;

public class StaticArithmetic {
public static int add(int a, int b) {
	return a+b;
}
}
