package com.methodreference;

public class Message {
Message(String msg){
	System.out.println(msg);
}
}
