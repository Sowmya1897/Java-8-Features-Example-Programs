package com.methodreference;

import java.util.function.BiFunction;

public class MethodReference {
public static void saySomething() {
System.out.println("Hello, this is static method");
}
public static void main(String[] args) {
	Sayable s = MethodReference::saySomething;
	s.say();


BiFunction<Integer, Integer, Integer> adding = StaticArithmetic::add;
int result = adding.apply(10,20);
System.out.println(result);
}
}
