package com.methodreference;

import java.util.function.BiFunction;

public class InstanceMethodReference {
public void saySomething() {
	System.out.println("Hello, this is an instance method");
}
public static void main(String[] args) {
	InstanceMethodReference imr = new InstanceMethodReference();
	
	//using reference
	Sayable saying = imr::saySomething;
	saying.say();
	
	//using anonymous object
	Sayable said = new InstanceMethodReference()::saySomething;
	said.say();
	
	BiFunction<Integer,Integer,Integer> adder = new Arithmetic()::add;
	int result = adder.apply(30,50);
	System.out.println(result);
}
}
