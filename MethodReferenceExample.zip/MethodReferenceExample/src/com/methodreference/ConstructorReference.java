package com.methodreference;

public class ConstructorReference {
public static void main(String[] args) {
	Messageable m = Message::new;
	m.getMessage("Hello Sowmya");
}
}
