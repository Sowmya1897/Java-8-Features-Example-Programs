package com.methodreference;

public class Arithmetic {
public int add(int a, int b) {
	return a+b;
}
}
