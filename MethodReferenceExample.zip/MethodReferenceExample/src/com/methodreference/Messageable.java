package com.methodreference;

public interface Messageable {
Message getMessage(String msg);
}
