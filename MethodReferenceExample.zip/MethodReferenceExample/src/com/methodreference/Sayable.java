package com.methodreference;

public interface Sayable {
public void say();
}
