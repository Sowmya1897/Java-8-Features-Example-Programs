package com.foreach;

import java.util.ArrayList;
import java.util.List;

public class ForEachOrderedExample {
	public static void main(String[] args) {
		List<String> games = new ArrayList<String>();
		games.add("Football");
		games.add("Hokey");
		games.add("Basketball");
		games.add("Chess");
		System.out.println("----------Iterating elements by passing lambda expression--------- ");
		games.stream().forEachOrdered(gamesList -> System.out.println(gamesList));
		System.out.println("----------Iterating elements by passing method reference--------- ");
		games.stream().forEachOrdered(System.out::println);
	}
}
