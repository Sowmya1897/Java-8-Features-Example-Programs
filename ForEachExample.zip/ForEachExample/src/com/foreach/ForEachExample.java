package com.foreach;

import java.util.ArrayList;
import java.util.List;

public class ForEachExample {
public static void main(String[] args) {
	List<String> games = new ArrayList<String>();
	games.add("Football");
	games.add("Cricket");
	games.add("Vollyball");
	games.add("Chess");
	System.out.println("----------Iterating elements by passing lambda expression--------- ");
	games.forEach(gameList -> System.out.println(gameList));
	System.out.println("----------Iterating elements by passing method reference--------- ");
	games.forEach(System.out::println);
}
}
