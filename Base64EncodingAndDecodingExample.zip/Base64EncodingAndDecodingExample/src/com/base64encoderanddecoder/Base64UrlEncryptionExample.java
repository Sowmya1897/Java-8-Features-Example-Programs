package com.base64encoderanddecoder;

import java.util.Base64;

public class Base64UrlEncryptionExample {
	public static void main(String[] args) {  
          //Encoding
        Base64.Encoder encoder = Base64.getUrlEncoder();  
        
        String eStr = encoder.encodeToString("http://www.javatpoint.com/java-tutorial/".getBytes());  
        System.out.println("Encoded URL: "+eStr);  
       
        //Decoding
        Base64.Decoder decoder = Base64.getUrlDecoder();  
       
        String dStr = new String(decoder.decode(eStr));  
        System.out.println("Decoded URL: "+dStr);  
    }  
}
