package com.lambdaexample;

public class Product {
int id;
String productName;
float price;

public Product(int id, String productName, float price) {
	super();
	this.id = id;
	this.productName = productName;
	this.price = price;
}

}
