package com.lambdaexample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public class LambdaExpression {
public static void main(String[] args) {
	int width =100;
	
	 Drawable d = ()->{
		 System.out.println("Drawing width :"+width);
	 };
	 d.draw();
	 
	System.out.println("*****************");
	
	List<Product> list = new ArrayList<>();
	list.add(new Product(1,"Dell laptop", 50000f));
	list.add(new Product(2,"Hcl laptop", 45000f));
	list.add(new Product(3,"Keyboard", 32000f));
	list.add(new Product(4,"Mouse", 61000f));
	
	Collections.sort(list,(p1,p2) -> {
		return p1.productName.compareTo(p2.productName);
		
	});
	
	for(Product p :list) {
		System.out.println(p.id +" "+p.productName+" "+p.price);
	}
	
	
	System.out.println("*****************");
	
	Stream<Product> pro_list = list.stream().filter(p -> p.price>40000f);
	pro_list.forEach(product -> System.out.println(product.productName+":"+product.price));
}
}
