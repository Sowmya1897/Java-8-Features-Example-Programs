package com.lambdaexample;

public interface Drawable {
public void draw();
}
