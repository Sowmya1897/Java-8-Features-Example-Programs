package com.collectors;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class CollectorsExample {
public static void main(String[] args) {
	
	List<Products>productsList = new ArrayList<Products>();  
   
    productsList.add(new Products(1,"HP Laptop",25000f));  
    productsList.add(new Products(2,"Dell Laptop",30000f));  
    productsList.add(new Products(3,"Lenevo Laptop",28000f));  
    productsList.add(new Products(4,"Sony Laptop",28000f));  
    productsList.add(new Products(5,"Apple Laptop",90000f)); 
    
    List<Float> productPriceList = productsList.stream()
    		.map(p->p.price)
    		.collect(Collectors.toList());
    System.out.println(productPriceList);
    
    Set<Float> priceList = productsList.stream()
    		.map(p->p.price)
    		.collect(Collectors.toSet());
    System.out.println(priceList);
    
    Double sumPrices = productsList.stream()
    								.collect(Collectors.summingDouble(p->p.price));
    System.out.println("Sum of prices :"+sumPrices);
    
    Integer sumId = productsList.stream()
    		.collect(Collectors.summingInt(p->p.id));
    System.out.println("Sum of id's :"+sumId);
    
    Double average = productsList.stream()
    		.collect(Collectors.averagingDouble(p->p.price));
    System.out.println("Average price is :"+average);
    
    Long noOfElements = productsList.stream()
    		.collect(Collectors.counting());
    System.out.println("Total elements :"+noOfElements);
}
}
