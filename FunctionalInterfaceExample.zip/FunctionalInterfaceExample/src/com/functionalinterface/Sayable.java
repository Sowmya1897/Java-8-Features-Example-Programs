package com.functionalinterface;

public interface Sayable extends Doable {
public void say(String msg);

int hashCode();
String toString();
boolean equals(Object o);

}
