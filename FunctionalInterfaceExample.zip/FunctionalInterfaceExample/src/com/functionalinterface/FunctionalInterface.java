package com.functionalinterface;

public class FunctionalInterface implements Sayable {

	public void say(String msg) {
		System.out.println(msg);
	}
public static void main(String[] args) {
	FunctionalInterface fi = new FunctionalInterface();
	fi.say("This functional interface implementation");
	fi.doIt();
}
}
