package com.functionalinterface;

public interface Doable {
default void doIt() {
	System.out.println("Do now");
}
}
